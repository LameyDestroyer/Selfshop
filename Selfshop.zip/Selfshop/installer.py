import tkinter as tk
from tkinter import simpledialog, filedialog
import shutil
import os
import sqlite3


def collect_user_input():
    root = tk.Tk()
    root.withdraw()  # Hide the main window

    admin_email = simpledialog.askstring("Webshop Setup", "Enter your admin email:")
    admin_password = simpledialog.askstring("Webshop Setup", "Enter your admin password:", show='*')
    shop_name = simpledialog.askstring("Webshop Setup", "Enter your shop name:")
    address = simpledialog.askstring("Webshop Setup", "Enter your address:")
    region = simpledialog.askstring("Webshop Setup", "Enter your region:")
    contact_email = simpledialog.askstring("Webshop Setup", "Enter your contact email:")
    phone_number = simpledialog.askstring("Webshop Setup", "Enter your phone number:")

    return admin_email, admin_password, shop_name, address, region, contact_email, phone_number


def extract_webshop_files(source, destination):
    print("Extracting webshop files...")
    try:
        shutil.copytree(source, destination, dirs_exist_ok=True)
    except shutil.Error as e:
        print(f"Error: {e}")
        exit(1)


def select_destination_directory():
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    return filedialog.askdirectory(title="Select Destination Directory")


def connect_to_database(database_path):
    print("Connecting to the SQLite database...")
    try:
        print(f"Database path: {database_path}")
        if not os.path.exists(database_path):
            print("Error: Database file does not exist.")
            exit(1)

        conn = sqlite3.connect(database_path)
        cursor = conn.cursor()
        print("Connected to the database successfully!")
        return conn, cursor
    except sqlite3.Error as e:
        print(f"Error connecting to the database: {e}")
        exit(1)


def setup_database(conn, cursor, admin_email, admin_password, shop_name, address, region, contact_email, phone_number):
    print("Setting up database...")
    try:
        # Insert admin user
        print("Inserting admin user...")
        cursor.execute('INSERT INTO "USER" (email, password, isAdmin) VALUES (?, ?, ?)',
                       (admin_email, admin_password, True))
        print("Admin user inserted successfully.")

        # Check if SHOP table is empty
        cursor.execute('SELECT COUNT(*) FROM SHOP')
        if cursor.fetchone()[0] == 0:
            # SHOP table is empty, perform INSERT
            print("Inserting shop details...")
            cursor.execute('INSERT INTO SHOP (shopName, address, region, contactMail, phoneNr, currency) VALUES (?, ?, ?, ?, ?, ?)',
                           (shop_name, address, region, contact_email, phone_number, "$"))
        else:
            # SHOP table has existing rows, perform UPDATE
            print("Updating shop details...")
            cursor.execute(
                'UPDATE SHOP SET shopName = ?, address = ?, region = ?, contactMail = ?, phoneNr = ?, WHERE shopId > 0',
                (shop_name, address, region, contact_email, phone_number))

        conn.commit()
        print("Database setup completed successfully!")
    except sqlite3.Error as e:
        print(f"Error setting up database: {e}")
        conn.rollback()
        exit(1)


def main():
    # Get the directory of the current script
    script_dir = os.path.dirname(os.path.realpath(__file__))

    # Path to the "Webshop" folder relative to the script directory
    source = os.path.join(script_dir, "Webshop")

    # Collect user input
    admin_email, admin_password, shop_name, address, region, contact_email, phone_number = collect_user_input()

    # Prompt user to select destination directory
    destination = select_destination_directory()

    # Ensure destination directory exists
    if not destination:
        print("Error: No destination directory selected.")
        exit(1)

    # Extract webshop files
    extract_webshop_files(source, destination)

    # Path to the database file relative to the destination directory
    database_path = os.path.join(destination, "build", "Database", "mydb.db")

    # Connect to the SQLite database
    conn, cursor = connect_to_database(database_path)

    # Setup database
    setup_database(conn, cursor, admin_email, admin_password, shop_name, address, region, contact_email, phone_number)

    # Close the database connection
    conn.close()

    print("Webshop setup completed successfully!")

if __name__ == "__main__":
    main()
